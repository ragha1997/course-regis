package com.cg.cma.service;

import java.util.List;

import com.cg.cma.dao.CourseDao;
import com.cg.cma.dao.CourseDaoImpl;
import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;

public class CourseServiceImpl implements CourseService {
	private CourseDao cdao = new CourseDaoImpl();
	@Override
	public long inserCourse(Course course) throws CourseException {
		return cdao.insertCourse(course);
	}

	@Override
	public List<Course> getAllCourses() throws CourseException {
		return cdao.getAllCourses();
	}

	@Override
	public boolean updateCourse(Course course) throws CourseException {
		return cdao.updateCourse(course);
	}

	@Override
	public boolean deleteCourse(long courseId) throws CourseException {
		return cdao.deleteCourse(courseId);
	}
	public boolean validate(Course course) throws CourseException{
		if(course.getDuration()<=0 || course.getDuration()>100) {
			throw new CourseException("Duration sholud be more than 1 and less than 100");			
		}
		if(course.getFees()<=0) {
			throw new CourseException("Fee should not be negative");
		}
		if(!course.getCourseTitle().matches("[A-Za-z0-9]{3,}")) {
			throw new CourseException("Course Title should not include special charater");
		}
		return true;
	}
}
