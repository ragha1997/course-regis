package com.cg.cra.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.cra.dao.DBUtil;
import com.cg.cra.dto.Course;
import com.cg.cra.dto.Registration;
import com.cg.cra.exceptions.RegistrationException;
import com.cg.cra.logger.RegistrationLogger;

public class RegistrationDaoImpl implements RegistrationDao {
	private Connection conn;
	private Logger logger;
	@Override
	public List<Course> getAllCourses() throws RegistrationException {
		logger=RegistrationLogger.getLogger();
		String sql = "SELECT course_id, course_title, fees, duration FROM course";
		ArrayList<Course> clist = new ArrayList<>();
		conn = DBUtil.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			while(rst.next()) {
				Course c = new Course();
				c.setCourseId(rst.getLong("course_id"));
				c.setCourseTitle(rst.getString("course_title"));
				c.setFees(rst.getDouble("fees"));
				c.setDuration(rst.getInt("duration"));
				clist.add(c);
			}
			logger.info("Course details fetched");
		} catch (SQLException e) {
			logger.error("Problem in fetching the details "+e.getMessage());
			throw new RegistrationException("Problem in fetching the details ");
		}
		return clist;
	}
	private long generateRegistratioId() throws RegistrationException{
		String sql = "SELECT seq_reg_id.NEXTVAL FROM DUAL";
		conn = DBUtil.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getLong(1);
		} catch (SQLException e) {
			throw new RegistrationException("Problem in generating reg id "+e.getMessage());
		}
	}
	
	@Override
	public long registerCourse(Registration registration) throws RegistrationException {
		logger=RegistrationLogger.getLogger();
		registration.setRegId(generateRegistratioId());
		String sql = "INSERT INTO registration VALUES(?,?,?,?,?,?)";
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, registration.getRegId());
			pst.setString(2, registration.getStudentName());
			pst.setString(3,registration.getAddress());
			pst.setString(4, registration.getPhoneNo());
			pst.setDate(5,Date.valueOf(registration.getRegDate()));
			pst.setLong(6, registration.getCourseId());
			pst.executeUpdate();
			logger.info("Registration completed successfully for "+registration);
		} catch (SQLException e) {
			logger.error("Problem in inserting registration details" +e.getMessage());
			throw new RegistrationException("Problem in inserting "
					+ "registration details" +e.getMessage());
		}
		return registration.getRegId();
	}

	@Override
	public boolean validateCourseId(long courseId) throws RegistrationException {
		String sql = "SELECT count(*) FROM course WHERE course_id=?";
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setLong(1, courseId);
			ResultSet rst = pst.executeQuery();
			if(rst.next()) {
				int count = rst.getInt(1);
				if(count==1) {
					return true;
				}else {
					throw new RegistrationException("Invalid course id");
				}
			}
		} catch (SQLException e) {
			throw new RegistrationException("Problem in validation the "
					+ "course "+e.getMessage());
		}
		return false;
	}

}
